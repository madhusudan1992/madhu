//
//  serviceTypeMethods.swift
//  serverresponseUsingSingleton
//
//  Created by madhu on 12/28/18.
//  Copyright © 2018 madhu. All rights reserved.
//

import Foundation
enum serviceTypeMethod:String{
    
    case topFree  = "top-free"
    case topPaid  = "top-paid"
    case topgross  = "top-grossing-ipad"
}
